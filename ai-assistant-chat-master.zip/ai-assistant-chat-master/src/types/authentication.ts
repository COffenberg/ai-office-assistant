export type LoginState = {
  success: boolean;
  message: string;
} | null;

export type RegisterState = {
  success: boolean;
  message: string;
} | null;
