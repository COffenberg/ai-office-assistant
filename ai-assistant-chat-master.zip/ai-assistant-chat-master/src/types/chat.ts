export type ChatMessage = {
  query: string;
  answer: string;
  created_at: string;
};
